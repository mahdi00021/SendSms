<?php

namespace App\Jobs;

use App\Logs;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class SendSmsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
         $factory = new \MainSendFactory();

         $messages =  Logs::where(['status' => 'queued'])->All();

         foreach($messages as $sms){
             $factory->createApiSend(\SendRequest::getAvailableApi(\SendRequest::$apiNamesTest,
                 $sms->phoneNumber,$sms->body),
                 $sms->body,$sms->phoneNumber);
         }

    }

}
