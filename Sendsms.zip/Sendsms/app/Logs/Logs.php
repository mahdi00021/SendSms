<?php

class Logs
{

    public static function write(array $data)
    {
      try {
          $logs = new \App\Logs();
          $logs->body = $data['body'];
          $logs->phoneNumber = $data['phoneNumber'];
          $logs->status = $data['status'];
          $logs->nameApi = $data['nameApi'];
          $logs->error = $data['error'];
          $logs->saveOrFail();
      } catch (Throwable $e) {
      }
    }

}