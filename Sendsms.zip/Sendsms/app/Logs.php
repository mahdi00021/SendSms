<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * this class is model for using of orm in laravel
 * Class Logs
 * @package App
*/
class Logs extends Model
{
    protected $table = 'logs';
}
