<?php

/**
 * Class SmsAbstract
 * other class implement this Abstract
 */
abstract class SmsAbstract
{

    abstract public function getApi(): SmsSend;

    /**
     * this function access to send method of all api
     * @param $body
     * @param $phoneNumber
     * @param $nameApi
     * @return string
     */
    public function sendSms($body,$phoneNumber,$nameApi): string
    {
        $network = $this->getApi();
        $network->send($body,$phoneNumber,$nameApi);
    }


}