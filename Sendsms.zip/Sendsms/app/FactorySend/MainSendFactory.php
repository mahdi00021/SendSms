<?php

use App\Logs;

class MainSendFactory
{

    /**
     * this method return send sms of api that set in parameter
     * @param SmsAbstract $sms
     * @param $nameApi
     * @param $body
     * @param $phoneNumber
     * @return string
    */
    public function clientCode(SmsAbstract $sms,$nameApi, $body , $phoneNumber){

      return $sms->sendSms($nameApi, $body , $phoneNumber);

    }

    /**
     * this method is factory method for new api class
     * @param $nameApi
     * @param $body
     * @param $phoneNumber
    */
    public function createApiSend($nameApi, $body , $phoneNumber)
    {

        if($nameApi == 'fail' || $nameApi == 'unavailable'){
            echo 'Api fail or unavailable';
            $data['body'] =  $body;
            $data['phoneNumber'] = $phoneNumber;
            $data['status'] = 'queued';
            $data['nameApi'] = $nameApi;
            $data['error'] = 'true';
            if(Logs::where(['body' => $body ,'phoneNumber' => $phoneNumber])->count()== 0){

                \Logs::write($data);
            }

        }
        else {
            $className =  $nameApi;

            if (class_exists($className)) {
                echo 'Api name is: '.$className.'SenderBridge';
                $this->clientCode( new ($className.'SenderBridge'),$nameApi, $body , $phoneNumber);
            }
            else
                echo 'Api not found';
        }

    }
}