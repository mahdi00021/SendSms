<?php

/**
 * this will implement by all class api
 * Interface SmsSend
*/
interface SmsSend
{
    public function send($body,$phoneNumber,$nameApi);
}