<?php

class Api2 implements SmsSend
{

    /**
     * this method send sms with Api
     * @param $body
     * @param $phoneNumber
     * @param $nameApi
     */
    public function send($body, $phoneNumber, $nameApi)
    {
        $url = 'http://api2.com/send/sms';
        SendRequest::send($url, $body, $phoneNumber, $nameApi);
    }
}

