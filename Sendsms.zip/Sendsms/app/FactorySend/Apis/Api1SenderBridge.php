<?php

class Api1SenderBridge extends SmsAbstract
{

    /**
     * THIS METHOD is like bridge to class api
     * @return SmsSend
    */
    public function getApi(): SmsSend
    {
       return new Api1();
    }
}