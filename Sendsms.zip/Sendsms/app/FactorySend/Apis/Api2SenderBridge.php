<?php

class Api2SenderBridge extends SmsAbstract
{

    /**
     * THIS METHOD is like bridge to class api
     * @return SmsSend
    */
    public function getApi(): SmsSend
    {
        return new Api2();
    }
}

