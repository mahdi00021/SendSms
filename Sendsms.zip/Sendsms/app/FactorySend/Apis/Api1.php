<?php

class Api1 implements SmsSend
{
    /**
     * this method send sms with Api
     * @param $body
     * @param $phoneNumber
     * @param $nameApi
     */
    public function send($body,$phoneNumber,$nameApi)
    {
        $url = 'http://api1.com/send/sms';
        SendRequest::send($url ,$body,$phoneNumber,$nameApi);
    }
}