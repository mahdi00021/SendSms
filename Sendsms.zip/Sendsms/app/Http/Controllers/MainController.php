<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MainController extends Controller
{
    /**
     * this method will send sms with valid api that get of getAvailableApi()
     * also get query string value of request
     * @param Request $request
    */
    public function sendSms(Request $request)
    {
       $factory = new \MainSendFactory();

       $nameApi = \SendRequest::getAvailableApi(\SendRequest::$apiNamesTest,
           $request->query('number'),
           $request->query('body')
       );

      $factory->createApiSend($nameApi,$request->query('body'),$request->query('number'));
    }

    /**
     * this method report of all our options for example :
     * count Sms sent
     * usage of Api
     * percent of Error Api
     * ten top Number in all
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
    */
    public function reportAll()
    {
        $context = new \ContextReport(new \CountAllSmsSent());
        $data['countSms'] = (int) $context->doOperation();

        $context = new \ContextReport(new \UsageOfApi());
        $usageApi =  $context->doOperation();
        $data['usageApi1'] = $usageApi['api1']; // we can put IN loop $data['usageApi'] = $usageApi;
        $data['usageApi2'] = $usageApi['api2'];

        $context = new \ContextReport(new \PercentErrorApi());
        $api =  $context->doOperation();
        $data['percentErrorApi1'] = $api['api1'].'%'; // we can put IN loop $data['percentErrorApi'] = $api;
        $data['percentErrorApi2'] = $api['api2'].'%';

        $context = new \ContextReport(new \TopNumberUsage());
        $topNumber =  $context->doOperation();
        $data['topNumber'] = $topNumber;

        return view('reportAll', $data);
    }

    /**
     * this method return records with input number that will get of request
     * this also will return one json of all record that searched with phone number
     * @param Request $request
     * @return mixed
    */
    public function reportOfSearchNumber(Request $request)
    {
        $context = new \ContextReport(new \SearchNumber($request->input('number')));
        return $topNumber = $context->doOperation();
    }
}
