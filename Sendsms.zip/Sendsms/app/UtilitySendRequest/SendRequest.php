<?php


use App\Logs;

class SendRequest
{
    //address test api for understand that which will work?
    public static $apiNamesTest = [
        'Api1' =>'http://api1.com/body=test&sms/send/?number=989121111111/localhost:81',
        'Api2' =>'http://api2.com/body=test&sms/send/?number=989121111111/localhost:82'
    ];

    /**
     * this method will test api address for understand that which will work?
     * and return name api for instance class api
     * this also will change invalid api with valid api
     * @param $apiNames
     * @param $phoneNumber
     * @param $body
     * @return string
    */
    public static function getAvailableApi($apiNames,$phoneNumber,$body)
    {
        $available ='';
        $node_count = count($apiNames);
        $curl_arr = array();
        $master = curl_multi_init();
        $keys = array_keys($apiNames);
        for($i = 0; $i < $node_count; $i++)
        {
            $url = $apiNames[$keys[$i]];
            $curl_arr[$i] = curl_init($url);
            curl_setopt($curl_arr[$i], CURLOPT_RETURNTRANSFER, true);
            curl_multi_add_handle($master, $curl_arr[$i]);
        }

        do {
            curl_multi_exec($master,$running);
        } while($running > 0);


        for($i = 0; $i < $node_count; $i++)
        {
            $results = curl_multi_getcontent( $curl_arr[$i] );
            if($results == 'ok')
            {
                $available = $keys[$i];
                break;
            }
            elseif($results == 'fail')
            {
                $data['nameApi'] = $keys[$i];
                $data['error'] = 'true';
                $data['body'] = $body;
                $data['phoneNumber'] = $phoneNumber;
                $data['status'] = 'fail';
                \Logs::write($data);

            }
            else
            {
                $available = 'unavailable';

            }
        }
        return $available;
    }


    /**
     * this method after above method will send sms with url and data itself
     * this method will implement by all Api
     * @param $url
     * @param $body
     * @param $phoneNumber
     * @param $nameApi
     * @return mixed
    */
    public static function send($url ,$body,$phoneNumber,$nameApi)
    {
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL,$url.'?body='.$body.'&number='.$phoneNumber);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);

        $output = curl_exec($ch);
        if($output == 'sent' || $output == 'ok')
        {
            echo 'Success sent sms';
            $data['body'] =  $body;
            $data['phoneNumber'] = $phoneNumber;
            $data['status'] = 'sent';
            $data['nameApi'] = $nameApi;
            $data['error'] = 'false';
            if(Logs::where(['body' => $body ,'phoneNumber' => $phoneNumber])->count()== 0){

                \Logs::write($data);
            }
            else{
               Logs::where(['body' => $body ,'phoneNumber' => $phoneNumber])->update(['status' => 'sent']);
            }

        }
        else
        {
            self::send($url ,$body,$phoneNumber,self::getAvailableApi(self::$apiNamesTest,$phoneNumber,$body));
        }

        curl_close($ch);
        return $output;
    }
}