<?php

interface ReportStrategy
{
    public function doOperation();
}