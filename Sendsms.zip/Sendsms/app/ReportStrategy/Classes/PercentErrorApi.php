<?php
use App\Logs;
use Illuminate\Support\Facades\Cache;

class PercentErrorApi implements ReportStrategy
{

    /**
     * this method return Percent of Error Api
     * @return mixed
    */
    public function doOperation()
    {
        $errors = Cache::remember('error', 10, function() {

           return $error = Logs::select(['error','nameApi'])
                ->where(['error' => 'true'])
                ->selectRaw('COUNT(*) AS count')
                ->groupBy('error')
                ->orderByDesc('count')
                ->limit(2)
                ->get();

        });

        $totalError = $errors[0]['count'] + $errors[1]['count'];
        $percents = [];
        foreach ($errors as $err)
             $percents[$err->nameApi] = ($err->count / $totalError) * 100;

        return $percents;
    }
}