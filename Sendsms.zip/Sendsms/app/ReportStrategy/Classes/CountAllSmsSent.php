<?php


use App\Logs;
use Illuminate\Support\Facades\Cache;

class CountAllSmsSent implements ReportStrategy
{
    /**
     * this method return Count All Sms Sent
     * @return mixed
    */
    public function doOperation()
    {
        $counts = Cache::remember('status', 10, function() {

            return $count =  Logs::where(['status' => 'sent'])->Count();
        });
        return $counts;
    }
}