<?php

use App\Logs;

class TopNumberUsage implements ReportStrategy
{

    /**
     * this method return most ten number repeatedly of all phone number
     * @return mixed
    */
    public function doOperation()
    {
        $topNumbers = Cache::remember('phoneNumber', 10, function() {

           return $topNumber = Logs::select('phoneNumber')
                ->selectRaw('COUNT(*) AS count')
                ->groupBy('phoneNumber')
                ->orderByDesc('count')
                ->limit(10)
                ->get();

        });

        return $topNumbers;
    }

}