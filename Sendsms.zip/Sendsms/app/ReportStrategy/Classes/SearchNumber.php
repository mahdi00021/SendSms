<?php

use App\Logs;

class SearchNumber implements ReportStrategy
{
    private $phoneNumber;

    public function __construct($phoneNumber)
    {
       $this->phoneNumber = $phoneNumber;
    }

    /**
     * this method return record of every phone number , getting input number of post http request
     * @return mixed
    */
    public function doOperation()
    {
       return $data =  Logs::where(['phoneNumber' => $this->phoneNumber])->get();
    }
}