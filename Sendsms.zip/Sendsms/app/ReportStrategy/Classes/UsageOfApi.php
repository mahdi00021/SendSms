<?php

use App\Logs;
use Illuminate\Support\Facades\Cache;

class UsageOfApi implements ReportStrategy
{

    /**
     * this method return value of used two api
     * @return mixed
    */
    public function doOperation()
    {
        $allData = Cache::remember('nameApi', 10, function() {

            return $data = Logs::select('nameApi')
                ->selectRaw('COUNT(*) AS count')
                ->groupBy('nameApi')
                ->orderByDesc('count')
                ->limit(2)
                ->get();
        });
        $usage = [];
        foreach ($allData as $d)
            $usage[$d->nameApi] = (integer) $allData[$d->nameApi][$d->count];

        return $usage;
    }
}