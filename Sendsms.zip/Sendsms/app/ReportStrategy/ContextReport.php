<?php

class ContextReport implements ReportStrategy
{
    private $reportStrategy;

    public function __construct(ReportStrategy $reportStrategy){
        $this->reportStrategy = $reportStrategy;
    }

    public function doOperation(){
       return $this->reportStrategy->doOperation();
    }
}