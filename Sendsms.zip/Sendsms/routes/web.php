<?php
/**
 * Programmer : Mahdi Norouzi
 * Laravel 5.5 used
 * Redis
 * Mysql
 * Symfony components
 * Other libs php
*/

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/**
 * we using of Redis for cache Every 10 min SomeQuery in reports
 * also we using index database for SomeField that most do searching on they
 * Cache::remember() is used
*/


/**
 * we using of Factory pattern for Send sms and switch auto between APIs
 * also we using Strategy pattern for Report options
*/

/**
 * we using of queue for The messages/sms that theirs api unavailable or failed
 * with create one job and queue is path : App/Jobs/SendSmsJob.php
 * also we register that in kernel for run Task Scheduling
*/


/**
 * our routes are :
*/

Route::get('/sendSms', 'MainController@sendSms');

Route::get('/reportAll', 'MainController@reportAll');

Route::post('/reportOfSearchNumber', 'MainController@reportOfSearchNumber');


